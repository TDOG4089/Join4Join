# Join4Join Discord Bot

## Description

Get thousand of members and grow your server very fast with this j4j bot ! Finish now to advertise, bump, do partners to get members. This bot allow you to get members quickly. Farm servers to get a lot of coins and buy your members

## Self hosting quick setup

### Requirements

- NodeJS (tested using v12)

### Setup

1. `npm install`
1. Setup files
   1. rename the `config.exemple.json` script to `config.json` and fill in required data
   1. rename the `config.json.sqlite` script to `json.sqlite`
1. `node index.js`

### ⚠ Disclaimer

Why have you decided to stop verifying join 4 join bots?

Ultimately, these bots ride the line of what we consider "advertising" in a way that has been troubling to navigate at best. Our Developer Terms of Service is quite clear that using our API to target users with ads is not permitted behavior, and yet these bots do that exact thing more often than not. Worse off, while we have been clear that providing paid advertising slots is not permitted, many of these bots have deliberately obscured their payment options in their verification applications, hiding them in Patreon pages or in deeper levels of their bot. 

On top of that, we've always been uncomfortable with Join 4 Join's proclivity to create spam and toxic communities. We believe healthy communities on Discord are about engagement, discussion, and fostering friendships, not just making a number get bigger. To quote our Safety Center:

Join 4 Join is the process of advertising for others to join your server with the promise to join their server in return. This might seem like a quick and fun way to introduce people to your server and to join new communities, but there’s a thin line between Join 4 Join and spam. 

Even if these invitations are not unsolicited, they might be flagged by our spam filter. Sending a large number of messages in a short period of time creates a strain on our service. That may result in action being taken on your account.

While policies are in flux, and things may change in the future, we don't currently have reason to believe that these bots are a healthy part of our ecosystem, which is why we've taken this stance.
